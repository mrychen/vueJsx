# babel-plugin-resolve-type
